from django.contrib import admin
from store.models import registeration,Products,Cart,Order

# Register your models here.
admin.site.register(registeration)
admin.site.register(Products)
admin.site.register(Order)