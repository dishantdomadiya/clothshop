from django.contrib.auth.models import User
from django.db import models


# Create your models here.
class registeration(models.Model):
    name = models.CharField(max_length=50)
    contact = models.CharField(max_length=12)
    email = models.CharField(max_length=20)
    pwd = models.CharField(max_length=20)

    def __str__(self):
        return self.name


CATEGORY = (
    ('Top wear', 'Top wear'),
    ('Bottom wear', 'Bottom wear'),
    ('Suits & Blazers', 'Suits & Blazers'),
    ('Ties & Socks', 'Ties & Socks'),
    ('Ethnic Wear', 'Ethnic Wear'),
    ('Ethnic Bottoms', 'Ethnic Bottoms'),
    ('Night wear', 'Night wear'),
    ('Western wear', 'Western wear'),
    ('Boy\'s clothing', 'Boy\'s clothing'),
    ('Girl\'s clothing', 'Girl\'s clothing'),
    ('Baby Girl\'s clothing', 'Baby Boy\'s clothing'),
    ('Sports Gear', 'Sports Gear'),
    ('Nutrition', 'Nutrition')
)


class Products(models.Model):
    item_name = models.CharField(max_length=100)
    img = models.ImageField(upload_to='items/')
    price = models.FloatField()
    discount_price = models.FloatField(blank=True, null=True)
    category = models.CharField(choices=CATEGORY, max_length=20)
    description = models.TextField()

    def __str__(self):
        return self.item_name


class Cart(models.Model):
    u = models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    product = models.CharField(max_length=50)
    category = models.CharField(max_length=20)
    price = models.FloatField()
    qty = models.IntegerField()
    amount = models.CharField(max_length=20)

    def __str__(self):
        return self.product


class Order(models.Model):
    u = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    oid = models.CharField(max_length=6)
    product = models.CharField(max_length=50)
    qty = models.IntegerField()
    amount = models.CharField(max_length=20)
    rnm = models.CharField(max_length=20)
    add = models.TextField()
    mo = models.CharField(max_length=12)
    odt = models.DateField()
    otm = models.TimeField(null=True)

    def __str__(self):
        return self.product
