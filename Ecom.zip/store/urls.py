from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from store import views

urlpatterns = [
    path("", views.index, name="home"),
    path("login/", views.loginpage, name="login"),
    path("signup/", views.signup, name="signup"),
    path("description/<int:pk>/", views.desc, name="desc"),
    path("cart/", views.cart, name="cart"),
    path("logoutuser/", views.logoutuser, name="logoutuser"),
    path("remove/<int:p>/", views.remove, name="remove"),
    path("bill/", views.bill, name="bill"),
    path("orders/", views.order, name="order"),
    path("place/", views.place, name="place")
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
