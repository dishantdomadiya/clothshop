import random
from datetime import date, time, datetime

#from django.conf.global_settings import EMAIL_HOST_USER
from django.contrib import auth
from django.contrib.auth import logout, login
from django.contrib.auth.models import User
from django.core.mail import send_mail, EmailMessage
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.template.loader import render_to_string
from smtplib import SMTP_SSL as SMTP
from Ecom import settings
from Ecom.settings import EMAIL_HOST_USER
from store.models import registeration, Products, Cart, Order
from smtplib import SMTP

# Create your views here.
def index(request):
    item = Products.objects.all()
    return render(request, "index.html", {'products': item})


def loginpage(request):
    if request.method == "POST":
        un = request.POST.get('uname')
        pwd = request.POST.get('pass')
        user = auth.authenticate(username=un, password=pwd)
        if user is not None:
            login(request, user)
            # uid = User.objects.get(user.pk)
            return redirect("/")
        else:
            return render(request, "login.html")
    return render(request, "login.html")


def signup(request):
    if request.method == "POST":
        name = request.POST.get('name')
        contact = request.POST.get('contact')
        email = request.POST.get('email')
        pwd = request.POST.get('setpass')
        reg = registeration(name=name, contact=contact, email=email, pwd=pwd)
        u = User.objects.create_user(username=reg.email, password=reg.pwd)
        reg.save()
        u.save()
        return render(request, "login.html", {'m1': 'Account Created Successfully...!'})
    return render(request, "signup.html")


def desc(request, pk):
    item = Products.objects.get(pk=pk)
    if request.method == "POST":
        if request.user.is_authenticated:
            u = request.user
            product = item.item_name
            cat = item.category
            price = item.price
            qty = request.POST.get('qt')
            amt = float(item.price) * float(qty)
            cr = Cart(u=u, product=product, category=cat, price=price, qty=qty, amount=amt)
            cr.save()
            return render(request, "Description.html", {'m1': 'Product added to cart...!', 'products': item})
        else:
            return redirect("/login/")
    return render(request, "Description.html", {'products': item})


def cart(request):
    add = Cart.objects.filter(u=request.user)
    return render(request, "cart.html", {'cart': add})


def logoutuser(request):
    logout(request)
    return redirect("/")


def remove(request, p):
    item = Cart.objects.get(pk=p)
    item.delete()
    return redirect("/cart/")


def bill(request):
    """html = render_to_string('print_bill.html')
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'filename=certificate_{}' + '.pdf'
    pdf = weasyprint.HTML(string=html, base_url='http://8d8093d5.ngrok.io/users/process/').write_pdf(
        stylesheets=[weasyprint.CSS(string='body { font-family: serif}')])
    to_emails = list("kariyabhaving@gmail.com")
    subject = "Shopping Bill..."
    email = EmailMessage(subject, body=pdf, from_email=settings.EMAIL_HOST_USER, to=to_emails)
    email.attach("certificate_{}" + '.pdf', pdf, "application/pdf")
    email.content_subtype = "pdf"  # Main content is now text/html
    email.encoding = 'us-ascii'
    email.send()"""
    return render(request, "print_bill.html")


def order(request):
    ord = Order.objects.filter(u=request.user)
    return render(request, "order.html", {'order': ord, 'em': EMAIL_HOST_USER})


def place(request):
    if request.user.is_authenticated:
        u = request.user
        rnm = request.POST.get('rnm')
        mo = request.POST.get('mo')
        add = request.POST.get('add')
        item = Cart.objects.filter(u=request.user)
        odt = date.today()
        otm = datetime.now().strftime("%H:%M %p")
        for i in item:
            oid = "OD" + str(random.randint(1000, 9999))
            ord = Order(u=u, oid=oid, product=i.product, qty=i.qty, amount=i.amount, rnm=rnm, add=add, mo=mo, odt=odt,
                        otm=otm)
            ord.save()
        subject = 'Bill From ClothShop...!'

        head = "We Recived your order, You have ordered following items : "
        pay = 0.0
        items = ""
        j = 1
        for i in item:
            items = items + "\n  " + str(j) + ". - " + str(i.product) + " : " + str(i.qty) + " * " + str(
                i.price) + " = " + str(i.amount) + "₹"
            pay = pay + float(i.amount)
            j += 1
        pb = "\n Total Payable Amount is : " + str(pay) + "₹ \n\n Thank you for shopping...!  \n Visit Again :)"
        message = head + "\n" + items + " \n " + pb
        send_mail(subject, message, EMAIL_HOST_USER, [request.user.username], fail_silently=False)
        item.delete()
        return redirect("/orders/")
